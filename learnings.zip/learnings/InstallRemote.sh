# Install Graal VM
sudo su
    rpm -qa | grep openjdk | xargs  yum -y remove
mkdir -m777 /home/cloud_user/GRAAL_VM
cd /home/cloud_user/GRAAL_VM
wget https://github.com/graalvm/graalvm-ce-builds/releases/download/vm-20.0.0/graalvm-ce-java11-linux-amd64-20.0.0.tar.gz
tar -xvf graalvm-ce-java11-linux-amd64-20.0.0.tar.gz
rm -rf graalvm-ce-java11-linux-amd64-20.0.0.tar.gz
sudo yum install gcc glibc-devel zlib-devel libstdc++-static -y
export GRAALVM_HOME=/home/cloud_user/GRAAL_VM/graalvm-ce-java11-20.0.0
export JAVA_HOME=${GRAALVM_HOME}
export PATH=${GRAALVM_HOME}/bin:$PATH
${GRAALVM_HOME}/bin/gu install native-image

# Install Maven
mkdir -m777 /home/cloud_user/MAVEN
mkdir -m777 /home/cloud_user/MAVEN/maven_lib_home
cd /home/cloud_user/MAVEN
wget http://apachemirror.wuchna.com/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.tar.gz
tar -xvf apache-maven-3.6.3-bin.tar.gz
rm -rf apache-maven-3.6.3-bin.tar.gz

# Install Node.js
cd /home/cloud_user
wget https://yum.oracle.com/repo/OracleLinux/OL7/developer/nodejs12/x86_64/getPackage/nodejs-12.16.3-1.0.1.el7.x86_64.rpm
sudo rpm -ivh nodejs-12.16.3-1.0.1.el7.x86_64.rpm
rm -rf nodejs-12.16.3-1.0.1.el7.x86_64.rpm
node --version

# Setting profile details
mkdir -m777 /home/cloud_user/Home
mkdir -m777 /home/cloud_user/npm-global
vi ~/.bashrc
   /home/cloud_user/.bash_profile
vi ~/.bash_profile
    # Change Home Directory
    export HOME=/home/cloud_user/Home

    # Java and Graal VM Configuration
    export GRAALVM_HOME=/home/cloud_user/GRAAL_VM/graalvm-ce-java11-20.0.0
    export JAVA_HOME=${GRAALVM_HOME}
    export PATH=${GRAALVM_HOME}/bin:$PATH
    export M2_HOME=/home/cloud_user/MAVEN/apache-maven-3.6.3
    export M2=${M2_HOME}/bin
    export PATH=${M2}:$PATH

    # Node.js Configuration
    export PATH=/home/cloud_user/npm-global/bin:$PATH

# Configure Docker
cd /home/cloud_user
mkdir -m777 docker_storage
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
wget http://mirror.centos.org/centos/7/extras/x86_64/Packages/container-selinux-2.119.1-1.c57a6f9.el7.noarch.rpm
sudo rpm -ivh container-selinux-2.119.1-1.c57a6f9.el7.noarch.rpm
rm -rf container-selinux-2.119.1-1.c57a6f9.el7.noarch.rpm
sudo yum install docker-ce

# Enabling Docker
sudo su
    chmod 777 /var/run/docker.sock
    systemctl  stop docker
    /usr/sbin/usermod -a -G docker ${USER}
    /usr/sbin/sysctl net.ipv4.conf.all.forwarding=1
    systemctl edit docker
        {
            "data-root":"/home/cloud_user/docker_storage"
        }
    systemctl  start docker
    chmod 777 /var/run/docker.sock
    exit
docker info
docker run hello-world

# Install Docker Compose
sudo wget https://github.com/docker/compose/releases/download/1.25.5/docker-compose-Linux-x86_64
sudo mv docker-compose-Linux-x86_64 /usr/bin/docker-compose
sudo chmod +x /usr/bin/docker-compose
docker-compose --version

# Install MySQL
sudo yum remove mysql mysql-server
cd /home/cloud_user
mkdir -m777 /home/cloud_user/MySQL
mkdir -m777 /home/cloud_user/MySQL/data
mkdir -m777 /home/cloud_user/MySQL/conf.d
vim /home/cloud_user/MySQL/conf.d/my-custom.cnf
  [mysqld]
  max_connections=200

docker run --name=mysql --env="MYSQL_ROOT_PASSWORD=root" -d -p 3306:3306 -v /home/cloud_user/MySQL/conf.d:/etc/mysql/conf.d -v /home/cloud_user/MySQL/data:/var/lib/mysql -d mysql:5.6.48
  # Login to the container
  docker exec -it mysql /bin/bash

  # If unable to login as Root user run below
  mysqld --skip-grant-tables
  mysql -u root -p
  # UPDATE user SET Password=PASSWORD('my_password') where USER='root';
  FLUSH PRIVILEGES;

  # Creating new DB Connection
  CREATE DATABASE reval;
  CREATE USER 'reval'@'%' IDENTIFIED BY 'reval';
  GRANT ALL PRIVILEGES ON reval.* TO 'reval'@'%';
  FLUSH PRIVILEGES;

  # Checking Users
  SELECT user, host FROM mysql.user;
  SELECT Host, User,ssl_type FROM user;
  SHOW VARIABLES LIKE 'skip_networking';
  SHOW GRANTS FOR 'root'@'%';
  SELECT USER(), CURRENT_USER();
  SHOW DATABASES;

  # Create Sample Table
  CREATE TABLE ofsll (
    id          INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    acc_nbr     VARCHAR(250),
    comment     VARCHAR(250),
    processed   CHAR(1)
  );

  INSERT INTO ofsll (
        acc_nbr,
        comment,
        processed
  ) VALUES (
        '123',
        'Doe     ',
        'N'
  );

  # Delete DB Connection
  DROP USER 'reval'@'%';
  DROP DATABASE reval;

docker rm -f mysql
sudo rm -rf /home/cloud_user/MySQL